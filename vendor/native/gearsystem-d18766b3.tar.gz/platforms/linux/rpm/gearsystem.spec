Name:           gearsystem
Version:        %{?version}%{!?version:1.0.0}
Release:        1%{?dist}
Summary:        Sega Master System / Game Gear / SG-1000 emulator

License:        GPL-3.0-or-later
URL:            https://github.com/drhelius/Gearsystem
Source0:        https://github.com/drhelius/Gearsystem/archive/refs/tags/%{version}.tar.gz

BuildRequires:  gcc-c++
BuildRequires:  gcc
BuildRequires:  make
BuildRequires:  pkgconf-pkg-config
BuildRequires:  mesa-libGL-devel
BuildRequires:  SDL3-devel
BuildRequires:  libatomic

Requires:       mesa-libGL
Requires:       SDL3
Requires:       shared-mime-info

%description
Gearsystem is a very accurate, cross-platform Sega Master System /
Game Gear / SG-1000 emulator written in C++.

%prep
%autosetup -n Gearsystem-%{version}

%build
export CXXFLAGS="$CXXFLAGS -fno-var-tracking-assignments"

%make_build -C platforms/linux \
    GIT_VERSION="%{version}" \
    USE_CLANG=0 \
    DEBUG=0

%install
install -Dm755 platforms/linux/%{name} %{buildroot}%{_prefix}/lib/%{name}/%{name}
install -dm755 %{buildroot}%{_bindir}
ln -s ../lib/%{name}/%{name} %{buildroot}%{_bindir}/%{name}

install -Dm644 platforms/shared/gamecontrollerdb.txt %{buildroot}%{_prefix}/lib/%{name}/gamecontrollerdb.txt

install -dm755 %{buildroot}%{_prefix}/lib/%{name}/mcp/resources/hardware
install -Dm644 platforms/shared/desktop/mcp/resources/hardware/toc.json %{buildroot}%{_prefix}/lib/%{name}/mcp/resources/hardware/toc.json

install -dm755 %{buildroot}%{_prefix}/lib/%{name}/shaders
install -Dm644 platforms/shared/desktop/shaders/*.gshader %{buildroot}%{_prefix}/lib/%{name}/shaders/
install -Dm644 platforms/shared/desktop/shaders/*.glsl %{buildroot}%{_prefix}/lib/%{name}/shaders/
install -Dm644 platforms/shared/desktop/shaders/README.md %{buildroot}%{_prefix}/lib/%{name}/shaders/

install -Dm644 platforms/linux/debian/%{name}.desktop %{buildroot}%{_datadir}/applications/%{name}.desktop
sed -i 's|/usr/games/gearsystem|gearsystem|g' %{buildroot}%{_datadir}/applications/%{name}.desktop
install -Dm644 platforms/linux/debian/%{name}.xml %{buildroot}%{_datadir}/mime/packages/%{name}.xml

for size in 16 24 32 48 64 128 256 512; do
    install -Dm644 platforms/shared/desktop/icons/gearsystem-${size}.png %{buildroot}%{_datadir}/icons/hicolor/${size}x${size}/apps/%{name}.png
done

install -Dm644 platforms/linux/debian/%{name}.6 %{buildroot}%{_mandir}/man6/%{name}.6

%files
%license LICENSE
%doc README.md
%{_bindir}/%{name}
%{_prefix}/lib/%{name}/
%{_datadir}/applications/%{name}.desktop
%{_datadir}/mime/packages/%{name}.xml
%{_datadir}/icons/hicolor/*x*/apps/%{name}.png
%{_mandir}/man6/%{name}.6*

%changelog
* %(date "+%a %b %d %Y") Nacho Sanchez <863613+drhelius@users.noreply.github.com> - %{version}-1
- Release %{version}
