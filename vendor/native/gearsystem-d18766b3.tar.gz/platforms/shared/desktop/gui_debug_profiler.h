/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef GUI_DEBUG_PROFILER_H
#define GUI_DEBUG_PROFILER_H

#include "gearsystem.h"

#ifdef GUI_DEBUG_PROFILER_IMPORT
    #define EXTERN
#else
    #define EXTERN extern
#endif

EXTERN void gui_debug_window_profiler(void);
EXTERN void gui_debug_profiler_update(void);
EXTERN void gui_debug_profiler_update_headless(void);
EXTERN void gui_debug_profiler_reset(void);
EXTERN void gui_debug_profiler_show(bool show);
EXTERN u32 gui_debug_profiler_get_frame_cycles(void);

#undef GUI_DEBUG_PROFILER_IMPORT
#undef EXTERN
#endif /* GUI_DEBUG_PROFILER_H */
