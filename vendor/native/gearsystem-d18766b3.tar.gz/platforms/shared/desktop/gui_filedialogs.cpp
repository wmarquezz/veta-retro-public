/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#define GUI_FILEDIALOGS_IMPORT
#include "gui_filedialogs.h"

#include <SDL3/SDL.h>
#include <string>
#include <cstring>
#include "gui.h"
#include "gui_actions.h"
#include "gui_notifications.h"
#include "gui_debug_memory.h"
#include "gui_debug_disassembler.h"
#include "gui_debug_trace_logger.h"
#include "gui_debug.h"
#include "gui_menus.h"
#include "gui_cheats.h"
#include "application.h"
#include "config.h"
#include "emu.h"
#include "utils.h"

enum FileDialogID
{
    FileDialog_None = 0,
    FileDialog_OpenROM,
    FileDialog_LoadRAM,
    FileDialog_SaveRAM,
    FileDialog_LoadState,
    FileDialog_SaveState,
    FileDialog_ChooseSavestatePath,
    FileDialog_ChooseScreenshotPath,
    FileDialog_ChooseVideoRecordingPath,
    FileDialog_ChooseTracePath,
    FileDialog_ChooseSavesPath,
    FileDialog_LoadSymbols,
    FileDialog_SaveScreenshot,
    FileDialog_SaveVGM,
    FileDialog_SaveVideo,
    FileDialog_SaveSprite,
    FileDialog_SaveAllSprites,
    FileDialog_SaveBackground,
    FileDialog_SaveTiles,
    FileDialog_SaveMemoryDumpBinary,
    FileDialog_SaveMemoryDumpText,
    FileDialog_LoadMemoryDumpBinary,
    FileDialog_SaveDisassemblerFull,
    FileDialog_SaveDisassemblerVisible,
    FileDialog_SaveLog,
    FileDialog_SaveDebugSettings,
    FileDialog_LoadDebugSettings,
    FileDialog_LoadSmsBootrom,
    FileDialog_LoadGgBootrom,
    FileDialog_ImportCheats,
};

static FileDialogID pending_dialog_id = FileDialog_None;
static std::string pending_dialog_path;
static bool dialog_active = false;
static bool pending_refocus_window = false;
static int pending_dialog_int_param1 = 0;
#if !defined(__APPLE__)
static bool was_exclusive_fullscreen = false;
#endif

static void SDLCALL file_dialog_callback(void* userdata, const char* const* filelist, int filter);
static const char* get_save_file_extension(FileDialogID id);
static std::string* get_dialog_folder(FileDialogID id);
static const char* get_dialog_location(FileDialogID id);
static void remember_dialog_location(FileDialogID id, const char* path);
static void show_open_file_dialog(FileDialogID id, const SDL_DialogFileFilter* filters, int filter_count);
static void show_save_file_dialog(FileDialogID id, const SDL_DialogFileFilter* filters, int filter_count);
static void show_open_folder_dialog(FileDialogID id);
static void process_dialog_result(FileDialogID id, const char* path);

static bool begin_dialog(void)
{
    if (dialog_active)
        return false;
    dialog_active = true;

#if !defined(__APPLE__)
    if (config_emulator.fullscreen && config_emulator.fullscreen_mode == 1)
    {
        was_exclusive_fullscreen = true;
        application_trigger_fullscreen(false);
    }
#endif

    return true;
}

static const char* get_save_file_extension(FileDialogID id)
{
    switch (id)
    {
        case FileDialog_SaveRAM:
            return ".sav";
        case FileDialog_SaveState:
            return ".state";
        case FileDialog_SaveScreenshot:
        case FileDialog_SaveSprite:
        case FileDialog_SaveBackground:
        case FileDialog_SaveTiles:
            return ".png";
        case FileDialog_SaveVGM:
            return ".vgm";
        case FileDialog_SaveVideo:
            return ".avi";
        case FileDialog_SaveMemoryDumpBinary:
            return ".bin";
        case FileDialog_SaveMemoryDumpText:
        case FileDialog_SaveDisassemblerFull:
        case FileDialog_SaveDisassemblerVisible:
        case FileDialog_SaveLog:
            return ".txt";
        case FileDialog_SaveDebugSettings:
            return ".ggdebug";
        default:
            return NULL;
    }
}

static std::string* get_dialog_folder(FileDialogID id)
{
    switch (id)
    {
        case FileDialog_OpenROM:
            return &config_file_dialogs.rom;
        case FileDialog_LoadRAM:
        case FileDialog_SaveRAM:
            return &config_file_dialogs.ram;
        case FileDialog_LoadState:
        case FileDialog_SaveState:
            return &config_file_dialogs.states;
        case FileDialog_SaveScreenshot:
            return &config_file_dialogs.screenshots;
        case FileDialog_SaveVGM:
        case FileDialog_SaveVideo:
            return &config_file_dialogs.recordings;
        case FileDialog_LoadSymbols:
        case FileDialog_SaveSprite:
        case FileDialog_SaveAllSprites:
        case FileDialog_SaveBackground:
        case FileDialog_SaveTiles:
        case FileDialog_SaveMemoryDumpBinary:
        case FileDialog_SaveMemoryDumpText:
        case FileDialog_LoadMemoryDumpBinary:
        case FileDialog_SaveDisassemblerFull:
        case FileDialog_SaveDisassemblerVisible:
        case FileDialog_SaveLog:
        case FileDialog_SaveDebugSettings:
        case FileDialog_LoadDebugSettings:
            return &config_file_dialogs.debug;
        case FileDialog_LoadSmsBootrom:
        case FileDialog_LoadGgBootrom:
            return &config_file_dialogs.bios;
        case FileDialog_ImportCheats:
            return &config_file_dialogs.cheats;
        default:
            return NULL;
    }
}

static const char* get_dialog_location(FileDialogID id)
{
    std::string* folder = get_dialog_folder(id);

    if (IsValidPointer(folder) && path_exists(folder->c_str()))
        return folder->c_str();

    return path_exists(config_file_dialogs.rom.c_str()) ? config_file_dialogs.rom.c_str() : NULL;
}

static void remember_dialog_location(FileDialogID id, const char* path)
{
    std::string* folder = get_dialog_folder(id);

    if (!IsValidPointer(folder))
        return;

    std::string location(path);
    SDL_PathInfo info;

    if (!SDL_GetPathInfo(path, &info) || (info.type != SDL_PATHTYPE_DIRECTORY))
        location.erase(location.find_last_of("/\\") + 1);
    else if (location.find_last_of("/\\") != location.size() - 1)
    {
        // Windows file dialogs take a location without a trailing separator as a file name
#if defined(_WIN32)
        location += '\\';
#else
        location += '/';
#endif
    }

    *folder = location;
}

static void show_open_file_dialog(FileDialogID id, const SDL_DialogFileFilter* filters, int filter_count)
{
    SDL_ShowOpenFileDialog(file_dialog_callback, (void*)(intptr_t)id, application_sdl_window, filters, filter_count, get_dialog_location(id), false);
}

static void show_save_file_dialog(FileDialogID id, const SDL_DialogFileFilter* filters, int filter_count)
{
    SDL_ShowSaveFileDialog(file_dialog_callback, (void*)(intptr_t)id, application_sdl_window, filters, filter_count, get_dialog_location(id));
}

static void show_open_folder_dialog(FileDialogID id)
{
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)id, application_sdl_window, get_dialog_location(id), false);
}

void gui_file_dialog_open_rom(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "ROM Files", "sms;gg;sg;mv;rom;bin;zip" } };
    show_open_file_dialog(FileDialog_OpenROM, filters, 1);
}

void gui_file_dialog_load_ram(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "RAM Files", "sav" } };
    show_open_file_dialog(FileDialog_LoadRAM, filters, 1);
}

void gui_file_dialog_save_ram(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "RAM Files", "sav" } };
    show_save_file_dialog(FileDialog_SaveRAM, filters, 1);
}

void gui_file_dialog_load_state(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Save State Files", "state;state1;state2;state3;state4;state5" } };
    show_open_file_dialog(FileDialog_LoadState, filters, 1);
}

void gui_file_dialog_save_state(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Save State Files", "state" } };
    show_save_file_dialog(FileDialog_SaveState, filters, 1);
}

void gui_file_dialog_choose_savestate_path(void)
{
    if (!begin_dialog())
        return;

    const char* default_path = config_emulator.savestates_path.empty() ? NULL : config_emulator.savestates_path.c_str();
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)FileDialog_ChooseSavestatePath, application_sdl_window, default_path, false);
}

void gui_file_dialog_choose_screenshot_path(void)
{
    if (!begin_dialog())
        return;

    const char* default_path = config_emulator.screenshots_path.empty() ? NULL : config_emulator.screenshots_path.c_str();
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)FileDialog_ChooseScreenshotPath, application_sdl_window, default_path, false);
}

void gui_file_dialog_choose_video_recording_path(void)
{
    if (!begin_dialog())
        return;

    const char* default_path = config_emulator.video_recordings_path.empty() ? NULL : config_emulator.video_recordings_path.c_str();
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)FileDialog_ChooseVideoRecordingPath, application_sdl_window, default_path, false);
}

void gui_file_dialog_choose_trace_path(void)
{
    if (!begin_dialog())
        return;

    const char* default_path = config_debug.trace_disk_path.empty() ? NULL : config_debug.trace_disk_path.c_str();
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)FileDialog_ChooseTracePath, application_sdl_window, default_path, false);
}

void gui_file_dialog_load_symbols(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Symbol Files", "sym;noi" }, { "All Files", "*" } };
    show_open_file_dialog(FileDialog_LoadSymbols, filters, 2);
}

void gui_file_dialog_save_screenshot(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "PNG Files", "png" } };
    show_save_file_dialog(FileDialog_SaveScreenshot, filters, 1);
}

void gui_file_dialog_save_vgm(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "VGM Files", "vgm" } };
    show_save_file_dialog(FileDialog_SaveVGM, filters, 1);
}

void gui_file_dialog_save_video(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "AVI Files", "avi" } };
    show_save_file_dialog(FileDialog_SaveVideo, filters, 1);
}

void gui_file_dialog_save_sprite(int index)
{
    if (!begin_dialog())
        return;

    pending_dialog_int_param1 = index;
    SDL_DialogFileFilter filters[] = { { "PNG Files", "png" } };
    show_save_file_dialog(FileDialog_SaveSprite, filters, 1);
}

void gui_file_dialog_save_all_sprites(void)
{
    if (!begin_dialog())
        return;

    show_open_folder_dialog(FileDialog_SaveAllSprites);
}

void gui_file_dialog_save_background(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "PNG Files", "png" } };
    show_save_file_dialog(FileDialog_SaveBackground, filters, 1);
}

void gui_file_dialog_save_tiles(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "PNG Files", "png" } };
    show_save_file_dialog(FileDialog_SaveTiles, filters, 1);
}

void gui_file_dialog_save_memory_dump(bool binary)
{
    if (!begin_dialog())
        return;

    FileDialogID id = binary ? FileDialog_SaveMemoryDumpBinary : FileDialog_SaveMemoryDumpText;
    SDL_DialogFileFilter filters[] = { { "Memory Dump Files", binary ? "bin" : "txt" } };
    show_save_file_dialog(id, filters, 1);
}

void gui_file_dialog_load_memory_dump()
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Memory Dump Files", "bin" } };
    show_open_file_dialog(FileDialog_LoadMemoryDumpBinary, filters, 1);
}

void gui_file_dialog_save_disassembler(bool full)
{
    if (!begin_dialog())
        return;

    FileDialogID id = full ? FileDialog_SaveDisassemblerFull : FileDialog_SaveDisassemblerVisible;
    SDL_DialogFileFilter filters[] = { { "Disassembler Files", "txt" } };
    show_save_file_dialog(id, filters, 1);
}

void gui_file_dialog_save_log(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Log Files", "txt" } };
    show_save_file_dialog(FileDialog_SaveLog, filters, 1);
}

void gui_file_dialog_save_debug_settings(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Debug Settings Files", "ggdebug" } };
    show_save_file_dialog(FileDialog_SaveDebugSettings, filters, 1);
}

void gui_file_dialog_load_debug_settings(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Debug Settings Files", "ggdebug" } };
    show_open_file_dialog(FileDialog_LoadDebugSettings, filters, 1);
}

void gui_file_dialog_choose_saves_path(void)
{
    if (!begin_dialog())
        return;

    const char* default_path = config_emulator.savefiles_path.empty() ? NULL : config_emulator.savefiles_path.c_str();
    SDL_ShowOpenFolderDialog(file_dialog_callback, (void*)(intptr_t)FileDialog_ChooseSavesPath, application_sdl_window, default_path, false);
}

void gui_file_dialog_load_sms_bootrom(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "BIOS Files", "bin;rom;bios;sms" } };
    show_open_file_dialog(FileDialog_LoadSmsBootrom, filters, 1);
}

void gui_file_dialog_load_gg_bootrom(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "BIOS Files", "bin;rom;bios;gg" } };
    show_open_file_dialog(FileDialog_LoadGgBootrom, filters, 1);
}

void gui_file_dialog_import_cheats(void)
{
    if (!begin_dialog())
        return;

    SDL_DialogFileFilter filters[] = { { "Cheat Files", "cht" } };
    show_open_file_dialog(FileDialog_ImportCheats, filters, 1);
}

void gui_file_dialog_process_results(void)
{
    bool refocus_window = pending_refocus_window && !dialog_active;

#if !defined(__APPLE__)
    if (was_exclusive_fullscreen && !dialog_active)
    {
        was_exclusive_fullscreen = false;
        application_trigger_fullscreen(true);
    }
#endif

    if (refocus_window)
        pending_refocus_window = false;

    if (pending_dialog_id != FileDialog_None)
    {
        FileDialogID id = pending_dialog_id;
        std::string path = pending_dialog_path;
        pending_dialog_id = FileDialog_None;
        pending_dialog_path.clear();
        remember_dialog_location(id, path.c_str());
        process_dialog_result(id, path.c_str());
    }

    if (refocus_window)
        application_refocus_window();
}

bool gui_file_dialog_is_active(void)
{
    return dialog_active;
}

static void SDLCALL file_dialog_callback(void* userdata, const char* const* filelist, int filter)
{
    (void)filter;
    dialog_active = false;
    pending_refocus_window = true;

    FileDialogID id = (FileDialogID)(intptr_t)userdata;

    if (!filelist || !filelist[0])
        return;

    pending_dialog_id = id;
    pending_dialog_path = filelist[0];
    const char* extension = get_save_file_extension(id);
    if (extension)
        append_extension_if_missing(pending_dialog_path, extension);
}

static void process_dialog_result(FileDialogID id, const char* path)
{
    switch (id)
    {
        case FileDialog_OpenROM:
        {
            gui_load_rom(path);
            break;
        }
        case FileDialog_LoadRAM:
        {
            emu_load_ram(path, gui_get_force_configuration());
            gui_notify(gui_NotificationInfo, ICON_MD_SD_STORAGE, "RAM loaded", path);
            break;
        }
        case FileDialog_SaveRAM:
        {
            emu_save_ram(path);
            gui_notify(gui_NotificationInfo, ICON_MD_SD_STORAGE, "RAM saved", path);
            break;
        }
        case FileDialog_LoadState:
        {
            gui_action_load_state(path);
            break;
        }
        case FileDialog_SaveState:
        {
            gui_action_save_state(path);
            break;
        }
        case FileDialog_ChooseSavestatePath:
        {
            strncpy_fit(gui_savestates_path, path, sizeof(gui_savestates_path));
            config_emulator.savestates_path.assign(path);
            update_savestates_data();
            break;
        }
        case FileDialog_ChooseTracePath:
        {
            gui_debug_trace_logger_set_output_directory(path);
            break;
        }
        case FileDialog_ChooseScreenshotPath:
        {
            strncpy_fit(gui_screenshots_path, path, sizeof(gui_screenshots_path));
            config_emulator.screenshots_path.assign(path);
            break;
        }
        case FileDialog_ChooseVideoRecordingPath:
        {
            strncpy_fit(gui_video_recordings_path, path, sizeof(gui_video_recordings_path));
            config_emulator.video_recordings_path.assign(path);
            break;
        }
        case FileDialog_LoadSymbols:
        {
            gui_debug_reset_symbols();

            if (gui_debug_load_symbols_file(path))
                gui_notify(gui_NotificationSuccess, ICON_MD_LABEL, "Symbols loaded", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to load symbols", path);
            break;
        }
        case FileDialog_SaveScreenshot:
        {
            gui_action_save_screenshot(path);
            break;
        }
        case FileDialog_SaveVGM:
        {
            if (emu_start_vgm_recording(path))
                gui_notify(gui_NotificationInfo, ICON_MD_FIBER_MANUAL_RECORD, "VGM recording started", path, "vgm");
            else
                gui_notify(gui_NotificationError, NULL, "Unable to start VGM recording", path, "vgm");
            break;
        }
        case FileDialog_SaveVideo:
        {
            gui_action_start_video_recording(path);
            break;
        }
        case FileDialog_SaveSprite:
        {
            gui_action_save_sprite(path, pending_dialog_int_param1);
            break;
        }
        case FileDialog_SaveAllSprites:
        {
            gui_action_save_all_sprites(path);
            break;
        }
        case FileDialog_SaveBackground:
        {
            gui_action_save_background(path);
            break;
        }
        case FileDialog_SaveTiles:
        {
            gui_action_save_tiles(path);
            break;
        }
        case FileDialog_SaveMemoryDumpBinary:
        {
            gui_debug_memory_save_dump(path, true);
            gui_notify(gui_NotificationInfo, ICON_MD_SAVE, "Memory dump saved", path);
            break;
        }
        case FileDialog_SaveMemoryDumpText:
        {
            gui_debug_memory_save_dump(path, false);
            gui_notify(gui_NotificationInfo, ICON_MD_SAVE, "Memory dump saved", path);
            break;
        }
        case FileDialog_LoadMemoryDumpBinary:
        {
            gui_debug_memory_load_dump(path);
            gui_notify(gui_NotificationInfo, ICON_MD_FILE_UPLOAD, "Memory dump loaded", path);
            break;
        }
        case FileDialog_SaveDisassemblerFull:
        case FileDialog_SaveDisassemblerVisible:
        {
            if (gui_debug_save_disassembler(path, id == FileDialog_SaveDisassemblerFull))
                gui_notify(gui_NotificationSuccess, ICON_MD_CODE, "Disassembly saved", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to save the disassembly", path);
            break;
        }
        case FileDialog_SaveLog:
        {
            if (gui_debug_save_log(path))
                gui_notify(gui_NotificationSuccess, ICON_MD_DESCRIPTION, "Trace log saved", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to save the trace log", path);
            break;
        }
        case FileDialog_SaveDebugSettings:
        {
            if (gui_debug_save_settings(path))
                gui_notify(gui_NotificationSuccess, ICON_MD_BUG_REPORT, "Debug settings saved", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to save debug settings", path);
            break;
        }
        case FileDialog_LoadDebugSettings:
        {
            if (gui_debug_load_settings(path))
                gui_notify(gui_NotificationSuccess, ICON_MD_BUG_REPORT, "Debug settings loaded", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to load debug settings", path);
            break;
        }
        case FileDialog_ChooseSavesPath:
        {
            strncpy_fit(gui_savefiles_path, path, sizeof(gui_savefiles_path));
            config_emulator.savefiles_path.assign(path);
            break;
        }
        case FileDialog_LoadSmsBootrom:
        {
            strncpy_fit(gui_sms_bootrom_path, path, sizeof(gui_sms_bootrom_path));
            config_emulator.sms_bootrom_path.assign(path);
            emu_load_bootrom_sms(gui_sms_bootrom_path);

            if (emu_get_core()->GetMemory()->IsBootromLoaded(false))
                gui_notify(gui_NotificationSuccess, ICON_MD_MEMORY, "Master System boot ROM loaded", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to load the Master System boot ROM", path);
            break;
        }
        case FileDialog_LoadGgBootrom:
        {
            strncpy_fit(gui_gg_bootrom_path, path, sizeof(gui_gg_bootrom_path));
            config_emulator.gg_bootrom_path.assign(path);
            emu_load_bootrom_gg(gui_gg_bootrom_path);

            if (emu_get_core()->GetMemory()->IsBootromLoaded(true))
                gui_notify(gui_NotificationSuccess, ICON_MD_MEMORY, "Game Gear boot ROM loaded", path);
            else
                gui_notify(gui_NotificationError, NULL, "Unable to load the Game Gear boot ROM", path);
            break;
        }
        case FileDialog_ImportCheats:
        {
            int imported = 0;
            int skipped = 0;

            if (gui_cheats_import(path, &imported, &skipped))
            {
                char message[64];
                snprintf(message, sizeof(message), "%d cheats imported, %d skipped", imported, skipped);
                gui_notify(gui_NotificationSuccess, ICON_MD_AUTO_FIX_HIGH, message, path);
            }
            else
                gui_notify(gui_NotificationError, NULL, "Unable to import cheats", path);
            break;
        }
        default:
            break;
    }
}
