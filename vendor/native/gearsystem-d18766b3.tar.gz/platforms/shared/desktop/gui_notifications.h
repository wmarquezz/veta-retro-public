/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef GUI_NOTIFICATIONS_H
#define GUI_NOTIFICATIONS_H

#include <SDL3/SDL.h>
#include "imgui.h"
#include "fonts/IconsMaterialDesign.h"

#ifdef GUI_NOTIFICATIONS_IMPORT
    #define EXTERN
#else
    #define EXTERN extern
#endif

enum gui_NotificationType
{
    gui_NotificationInfo = 0,
    gui_NotificationSuccess,
    gui_NotificationWarning,
    gui_NotificationError
};

EXTERN void gui_notify(gui_NotificationType type, const char* icon, const char* message, const char* detail = NULL,
    const char* tag = NULL, Uint64 milliseconds = 0);
EXTERN void gui_notifications_render_output(const ImVec2& min, const ImVec2& max);
EXTERN void gui_notifications_render(void);

#undef GUI_NOTIFICATIONS_IMPORT
#undef EXTERN
#endif /* GUI_NOTIFICATIONS_H */
