/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <SDL3/SDL_main.h>
#include <stdlib.h>
#if !defined(_WIN32)
#include <signal.h>
#endif
#include "gearsystem.h"
#include "application.h"
#include "application_headless.h"
#include "config.h"
#include "console_utils.h"
#include "link_cable/link_cable_manager.h"

extern bool g_mcp_stdio_mode;
extern bool g_mcp_router_enabled;

static bool option_has_value(const char* option);
static const char* option_value(int argc, char* argv[], int* i);

int main(int argc, char* argv[])
{
#if !defined(_WIN32)
    signal(SIGPIPE, SIG_IGN);
#endif

    attach_parent_console(argc, argv);

    ApplicationParams app_params;
    bool show_usage = false;
    int ret = 0;
    bool mcp_stdio_set = false;
    bool mcp_http_set = false;
    bool headless = false;
    bool portable = false;

    for (int i = 1; i < argc; i++)
    {
        if (argv[i][0] == '-' || strcmp(argv[i], "/?") == 0)
        {
            if ((strcmp(argv[i], "-h") == 0) || (strcmp(argv[i], "-?") == 0) ||
                (strcmp(argv[i], "--help") == 0) || (strcmp(argv[i], "/?") == 0))
            {
                show_usage = true;
                ret = 0;
            }
            else if ((strcmp(argv[i], "-v") == 0) || (strcmp(argv[i], "--version") == 0))
            {
                printf("%s\n", GS_TITLE_ASCII);
                printf("Build: %s\n", GS_VERSION);
                printf("Author: Nacho Sánchez (drhelius)\n");
                return 0;
            }
            else if ((strcmp(argv[i], "-f") == 0) || (strcmp(argv[i], "--fullscreen") == 0))
            {
                app_params.force_fullscreen = true;
            }
            else if ((strcmp(argv[i], "-w") == 0) || (strcmp(argv[i], "--windowed") == 0))
            {
                app_params.force_windowed = true;
            }
            else if (strcmp(argv[i], "--mcp-stdio") == 0)
            {
                g_mcp_stdio_mode = true;  // Disable logging immediately
                mcp_stdio_set = true;
                app_params.mcp_mode = 0;
            }
            else if (strcmp(argv[i], "--mcp-http") == 0)
            {
                mcp_http_set = true;
                app_params.mcp_mode = 1;
            }
            else if ((strcmp(argv[i], "--mcp-router") == 0) || (strcmp(argv[i], "--mcp-enable-router") == 0))
            {
                g_mcp_router_enabled = true;
            }
            else if (strcmp(argv[i], "--headless") == 0)
            {
                headless = true;
            }
            else if (strcmp(argv[i], "--portable") == 0)
            {
                portable = true;
            }
            else if (strcmp(argv[i], "--load-state") == 0)
            {
                const char* value = option_value(argc, argv, &i);

                if (!value)
                    return -1;

                if ((strlen(value) == 1) && (value[0] >= '1') && (value[0] <= '5'))
                    app_params.state_slot = value[0] - '0';
                else
                    app_params.state_file = value;
            }
            else if (strcmp(argv[i], "--link-session") == 0)
            {
                if (i + 1 >= argc || argv[i + 1][0] == '-')
                {
                    fprintf(stderr, "Missing value for %s\n", argv[i]);
                    return -1;
                }

                char* end = NULL;
                long session = strtol(argv[++i], &end, 10);

                if (!end || *end != '\0' || session < 1 || session > 255)
                {
                    fprintf(stderr, "Invalid link cable session: %s\n", argv[i]);
                    return -1;
                }

                app_params.link_cable_session = (int)session;
                app_params.link_cable_session_set = true;
            }
            else if (strcmp(argv[i], "--link-stall-us") == 0)
            {
                if (i + 1 >= argc || argv[i + 1][0] == '-')
                {
                    fprintf(stderr, "Missing value for %s\n", argv[i]);
                    return -1;
                }

                char* end = NULL;
                long stall_us = strtol(argv[++i], &end, 10);

                if (!end || *end != '\0' || stall_us < 0 || stall_us > 10000)
                {
                    fprintf(stderr, "Invalid link cable stall threshold: %s\n", argv[i]);
                    return -1;
                }

                app_params.link_cable_stall_us = (int)stall_us;
                app_params.link_cable_stall_us_set = true;
            }
            else if (strcmp(argv[i], "--mcp-http-port") == 0)
            {
                if (i + 1 >= argc || argv[i + 1][0] == '-')
                {
                    fprintf(stderr, "Missing value for --mcp-http-port\n");
                    return -1;
                }

                char* end = NULL;
                long port = strtol(argv[++i], &end, 10);
                if (!end || *end != '\0' || port <= 0 || port > 65535)
                {
                    fprintf(stderr, "Invalid port number: %s\n", argv[i]);
                    return -1;
                }
                app_params.mcp_tcp_port = (int)port;
                app_params.mcp_tcp_port_set = true;
            }
            else if (strcmp(argv[i], "--mcp-http-address") == 0)
            {
                if (i + 1 >= argc || argv[i + 1][0] == '-')
                {
                    fprintf(stderr, "Missing value for --mcp-http-address\n");
                    return -1;
                }

                app_params.mcp_http_address = argv[++i];
                app_params.mcp_http_address_set = true;
            }
            else
            {
                printf("Unknown option: %s\n", argv[i]);
                show_usage = true;
                ret = -1;
            }
        }
    }

    int non_option_count = 0;
    for (int i = 1; i < argc; i++)
    {
        if (option_has_value(argv[i]))
        {
            if (i + 1 < argc)
                i++;
            continue;
        }

        if (argv[i][0] != '-' && strcmp(argv[i], "/?") != 0)
        {
            if (non_option_count == 0)
                app_params.rom_file = argv[i];
            else if (non_option_count == 1)
                app_params.symbol_file = argv[i];

            non_option_count++;

            if (non_option_count > 2)
            {
                show_usage = true;
                ret = -1;
                break;
            }
        }
    }

    if (mcp_stdio_set && mcp_http_set)
    {
        printf("Error: Cannot use both --mcp-stdio and --mcp-http at the same time\n");
        return -1;
    }

    if (show_usage)
    {
        printf("Usage: %s [options] [rom_file] [symbol_file]\n", argv[0]);
        printf("\nArguments:\n");
        printf("  [rom_file]                  ROM file: accepts ROMs (.sms, .gg, .sg, .mv) or ZIP (.zip)\n");
        printf("  [symbol_file]               Optional symbol file for debugging\n");
        printf("\nOptions:\n");
        printf("  -f, --fullscreen            Start in fullscreen mode\n");
        printf("  -w, --windowed              Start in windowed mode with menu visible\n");
        printf("      --load-state SLOT       Load save state slot 1-5, or a state file, once the media is loaded\n");
        printf("      --mcp-stdio             Auto-start MCP server with stdio transport\n");
        printf("      --mcp-http              Auto-start MCP server with HTTP transport\n");
        printf("      --mcp-router            Enable compact MCP tool routing\n");
        printf("      --mcp-http-address A    HTTP bind address (default: 127.0.0.1)\n");
        printf("      --mcp-http-port N       HTTP port for MCP server (default: 7777)\n");
        printf("      --headless              Run without GUI (requires MCP or Link Cable)\n");
        printf("      --link-session N        Connect to link cable session 1-255\n");
        printf("      --link-stall-us N       Override barrier stall threshold (0=default)\n");
        printf("      --portable              Store configuration and user data beside the application\n");
        printf("  -v, --version               Display version information\n");
        printf("  -h, --help                  Display this help message\n");
        return ret;
    }

    if (app_params.force_fullscreen && app_params.force_windowed)
        app_params.force_fullscreen = false;

    config_init(portable);
    config_read();

    if (app_params.mcp_tcp_port_set)
        config_emulator.mcp_tcp_port = app_params.mcp_tcp_port;
    else
        app_params.mcp_tcp_port = config_emulator.mcp_tcp_port;

    if (app_params.mcp_http_address_set)
        config_emulator.mcp_http_address = app_params.mcp_http_address;
    else
        app_params.mcp_http_address = config_emulator.mcp_http_address;

    if (app_params.link_cable_session_set)
        config_emulator.link_cable_session = app_params.link_cable_session;
    else
        app_params.link_cable_session = config_emulator.link_cable_session;

    if (app_params.link_cable_stall_us_set)
    {
        config_emulator.link_cable_stall_us =
            app_params.link_cable_stall_us == 0 ?
            (int)link_cable_normal_barrier_stall_us() :
            app_params.link_cable_stall_us;
    }

    if (headless)
    {
        ret = application_headless_init(app_params);

        if (ret == 0)
        {
            application_headless_mainloop();
            application_headless_destroy();
        }

        config_write();
        config_destroy();

        return ret;
    }

    if (!application_check_single_instance(app_params.rom_file, app_params.symbol_file))
    {
        config_destroy();
        return 0;
    }

    ret = application_init(app_params);

    if (ret == 0)
        application_mainloop();

    application_destroy();

    config_write();
    config_destroy();

    return ret;
}

static bool option_has_value(const char* option)
{
    static const char* const k_options[] = { "--mcp-http-port", "--mcp-http-address", "--link-session",
        "--link-stall-us", "--load-state" };

    for (size_t i = 0; i < sizeof(k_options) / sizeof(k_options[0]); i++)
    {
        if (strcmp(option, k_options[i]) == 0)
            return true;
    }

    return false;
}

static const char* option_value(int argc, char* argv[], int* i)
{
    if ((*i + 1 >= argc) || (argv[*i + 1][0] == '-'))
    {
        fprintf(stderr, "Missing value for %s\n", argv[*i]);
        return NULL;
    }

    return argv[++(*i)];
}
