/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef CARTRIDGE_H
#define	CARTRIDGE_H

#include <list>
#include "definitions.h"
#include "game_db.h"

class Cartridge
{
public:
    enum CartridgeTypes
    {
        CartridgeRomOnlyMapper,
        CartridgeSegaMapper,
        CartridgeCodemastersMapper,
        CartridgeSG1000Mapper,
        CartridgeKoreanMapper,
        CartridgeKoreanMSXSMS8000Mapper,
        CartridgeKoreanSMS32KB2000Mapper,
        CartridgeKoreanMSX32KB2000Mapper,
        CartridgeKorean2000XOR1FMapper,
        CartridgeKoreanMSX8KB0300Mapper,
        CartridgeKorean0000XORFFMapper,
        CartridgeKoreanFFFFHiComMapper,
        CartridgeKoreanFFFEMapper,
        CartridgeKoreanBFFCMapper,
        CartridgeKoreanFFF3FFFCMapper,
        CartridgeKoreanMDFFF5Mapper,
        CartridgeKoreanMDFFF0Mapper,
        CartridgeMSXMapper,
        CartridgeJanggunMapper,
        CartridgeMulti4PAKAllActionMapper,
        CartridgeJumboDahjeeMapper,
        CartridgeEeprom93C46Mapper,
        CartridgeIratahackMapper,
        CartridgeNotSupported
    };
    
    enum CartridgeZones
    {
        CartridgeJapanSMS,
        CartridgeExportSMS,
        CartridgeJapanGG,
        CartridgeExportGG,
        CartridgeInternationalGG,
        CartridgeUnknownZone
    };

    enum CartridgeRegions
    {
        CartridgeNTSC,
        CartridgePAL,
        CartridgeUnknownRegion
    };

    enum CartridgeSystem
    {
        CartridgeSMS,
        CartridgeGG2ASIC,
        CartridgeGG2ASICSMSMode,
        CartridgeGG1ASIC,
        CartridgeGG1ASICSMSMode,
        CartridgeSG1000,
        CartridgeSG1000II,
        CartridgeUnknownSystem
    };

    struct ForceConfiguration
    {
        CartridgeTypes type;
        CartridgeZones zone;
        CartridgeRegions region;
        CartridgeSystem system;
    };

public:
    Cartridge();
    ~Cartridge();
    void Init();
    void Reset();
    u32 GetCRC() const;
    bool IsGameGear() const;
    bool IsGameGearInSMSMode() const;
    int GetGameGearASIC() const;
    INLINE bool IsSG1000() const;
    bool IsSG1000II() const;
    bool IsPAL() const;
    bool IsValidROM() const;
    bool IsReady() const;
    bool IsInGameDatabase() const;
    const char* GetGameDatabaseName() const;
    INLINE bool HasRAMWithoutBattery() const;
    CartridgeTypes GetType() const;
    CartridgeZones GetZone() const;
    void ForceConfig(ForceConfiguration config);
    int GetFeatures() const;
    INLINE int GetROMSize() const;
    INLINE int GetROMBankCount() const;
    INLINE int GetROMBankCount8k() const;
    const char* GetFilePath() const;
    const char* GetFileName() const;
    const char* GetFileDirectory() const;
    INLINE u8* GetROM() const;
    bool LoadFromFile(const char* path, bool softpatching = false);
    bool LoadFromBuffer(const u8* buffer, int size, const char* path = NULL);
    bool IsSoftpatchApplied() const;
    const char* GetSoftpatchPath() const;
    void SetGameGenieCheat(const char* szCheat);
    void ClearGameGenieCheats();

private:
    bool GatherMetadata(u32 crc);
    void GetInfoFromDB(u32 crc);
    bool LoadFromZipFile(const u8* buffer, int size, bool softpatching);
    bool LoadFromBufferWithSoftpatch(const u8* buffer, int size, bool softpatching);
    bool TestValidROM(u16 location);
    void SetROMPath(const char* path);
    int CalculateROMBankCount(int romSize, int bankSize) const;

private:
    u8* m_pROM;
    int m_iROMSize;
    CartridgeTypes m_Type;
    CartridgeZones m_Zone;
    bool m_bValidROM;
    bool m_bReady;
    bool m_bInGameDatabase;
    const char* m_pGameDatabaseName;
    char m_szFilePath[512];
    char m_szFileName[512];
    char m_szFileDirectory[512];
    char m_szFileNameInZip[512];
    int m_iROMBankCount16k;
    int m_iROMBankCount8k;
    bool m_bGameGear;
    bool m_bGameGearInSMSMode;
    int m_iGameGearASIC;
    bool m_bSG1000;
    bool m_bSG1000II;
    bool m_bPAL;
    bool m_bRAMWithoutBattery;
    u32 m_iCRC;
    int m_iFeatures;
    bool m_softpatch_applied;
    char m_softpatch_path[4096];

    struct GameGenieCode
    {
        int address;
        u8 old_value;
    };

    std::list<GameGenieCode> m_GameGenieList;
};

INLINE bool Cartridge::IsSG1000() const
{
    return m_bSG1000;
}

INLINE bool Cartridge::HasRAMWithoutBattery() const
{
    return m_bRAMWithoutBattery;
}

INLINE int Cartridge::GetROMSize() const
{
    return m_iROMSize;
}

INLINE int Cartridge::GetROMBankCount() const
{
    return m_iROMBankCount16k;
}

INLINE int Cartridge::GetROMBankCount8k() const
{
    return m_iROMBankCount8k;
}

INLINE u8* Cartridge::GetROM() const
{
    return m_pROM;
}

#endif	/* CARTRIDGE_H */
